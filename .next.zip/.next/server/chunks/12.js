"use strict";
exports.id = 12;
exports.ids = [12];
exports.modules = {

/***/ 6517:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Discount = ({ discount , product , slug , modal  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            discount > 1 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: modal ? "absolute text-dark text-sm bg-orange-500 text-white py-1 px-2 rounded font-medium z-10 left-4 top-4" : slug ? "text-dark text-sm bg-orange-500 text-white py-1 px-2 rounded font-medium z-10 right-4 top-4" : " absolute text-dark text-xs bg-orange-500 text-white py-1 px-2 rounded font-medium z-10 right-4 top-4",
                children: [
                    discount.toFixed(0),
                    "% Off"
                ]
            }),
            discount === undefined && Number(product.prices.discount) > 1 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: modal ? "absolute text-dark text-sm bg-orange-500 text-white py-1 px-2 rounded font-medium z-10 left-4 top-4" : slug ? "text-dark text-sm bg-orange-500 text-white py-1 px-2 rounded font-medium z-10 right-4 top-4" : " absolute text-dark text-xs bg-orange-500 text-white py-1 px-2 rounded font-medium z-10 right-4 top-4",
                children: [
                    Number(product.prices.discount).toFixed(0),
                    "% Off"
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Discount);


/***/ }),

/***/ 7493:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Price = ({ product , price , card , currency , originalPrice  })=>{
    // console.log("price", price, "originalPrice", originalPrice, "card", card);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "font-serif product-price font-bold",
        children: product?.variants.length > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: card ? "inline-block text-lg font-semibold text-gray-800" : "inline-block text-2xl",
                    children: [
                        currency,
                        price
                    ]
                }),
                originalPrice > price && !card ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("del", {
                        className: card ? "sm:text-sm font-normal text-base text-gray-400 ml-1" : "text-lg font-normal text-gray-400 ml-1",
                        children: [
                            currency,
                            parseFloat(originalPrice).toFixed(2)
                        ]
                    })
                }) : null
            ]
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: card ? "inline-block text-lg font-semibold text-gray-800" : "inline-block text-2xl",
                    children: [
                        currency,
                        product?.prices?.price
                    ]
                }),
                originalPrice > price && card ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("del", {
                        className: card ? "sm:text-sm font-normal text-base text-gray-400 ml-1" : "text-lg font-normal text-gray-400 ml-1",
                        children: [
                            currency,
                            parseFloat(originalPrice).toFixed(2)
                        ]
                    })
                }) : null
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Price);


/***/ }),

/***/ 6616:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(866);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_1__);


const Stock = ({ stock , card  })=>{
    const { t  } = next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_1___default()();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: stock <= 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
            className: "bg-red-100 absolute z-10 text-red-500 dark:text-red-400 rounded-full inline-flex items-center justify-center px-2 py-0 text-xs font-medium font-serif",
            children: t("common:stockOut")
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: `${card ? "bg-gray-100 absolute z-10 text-emerald-500 rounded-full text-xs px-2 py-0 font-medium" : "bg-emerald-100 text-emerald-500 rounded-full inline-flex items-center justify-center px-2 py-0 text-xs font-semibold font-serif"}`,
                children: [
                    t("common:stock"),
                    " :",
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "text-red-500 dark:text-red-400 pl-1 font-bold",
                        children: [
                            stock,
                            " "
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Stock);


/***/ }),

/***/ 386:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Tags = ({ product  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: product.tag.length !== 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "flex flex-row",
            children: JSON.parse(product?.tag).map((t, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "bg-gray-50 mr-2 border-0 text-gray-600 rounded-full inline-flex items-center justify-center px-3 py-1 text-xs font-semibold font-serif mt-2",
                    children: t
                }, i + 1))
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Tags);


/***/ }),

/***/ 3794:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _component_common_Discount__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6517);
/* harmony import */ var _component_common_Price__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7493);
/* harmony import */ var _component_common_Stock__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6616);
/* harmony import */ var _component_common_Tags__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(386);
/* harmony import */ var _component_modal_MainModal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1173);
/* harmony import */ var _component_variants_VariantList__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2479);
/* harmony import */ var _context_SidebarContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6812);
/* harmony import */ var _hooks_useAddToCart__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1353);
/* harmony import */ var _utils_toast__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8548);
/* harmony import */ var _utils_translate__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(8837);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(866);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_15__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_component_modal_MainModal__WEBPACK_IMPORTED_MODULE_5__]);
_component_modal_MainModal__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

















const ProductModal = ({ modalOpen , setModalOpen , product , attributes , currency ,  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_13__.useRouter)();
    const { setIsLoading , isLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_14__.useContext)(_context_SidebarContext__WEBPACK_IMPORTED_MODULE_7__/* .SidebarContext */ .l);
    const { t , lang  } = next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_10___default()("ns1");
    const { handleAddItem , setItem , item  } = (0,_hooks_useAddToCart__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    // react hook
    const { 0: value , 1: setValue  } = (0,react__WEBPACK_IMPORTED_MODULE_14__.useState)("");
    const { 0: price , 1: setPrice  } = (0,react__WEBPACK_IMPORTED_MODULE_14__.useState)(0);
    const { 0: img , 1: setImg  } = (0,react__WEBPACK_IMPORTED_MODULE_14__.useState)("");
    const { 0: originalPrice , 1: setOriginalPrice  } = (0,react__WEBPACK_IMPORTED_MODULE_14__.useState)(0);
    const { 0: stock , 1: setStock  } = (0,react__WEBPACK_IMPORTED_MODULE_14__.useState)(0);
    const { 0: discount , 1: setDiscount  } = (0,react__WEBPACK_IMPORTED_MODULE_14__.useState)("");
    const { 0: selectVariant , 1: setSelectVariant  } = (0,react__WEBPACK_IMPORTED_MODULE_14__.useState)({});
    const { 0: selectVa , 1: setSelectVa  } = (0,react__WEBPACK_IMPORTED_MODULE_14__.useState)({});
    const { 0: variantTitle , 1: setVariantTitle  } = (0,react__WEBPACK_IMPORTED_MODULE_14__.useState)([]);
    const { 0: variants , 1: setVariants  } = (0,react__WEBPACK_IMPORTED_MODULE_14__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_14__.useEffect)(()=>{
        // console.log('value', value, product);
        if (value) {
            const result = product?.variants?.filter((variant)=>Object.keys(selectVa).every((k)=>selectVa[k] === variant[k]));
            const res = result?.map(({ originalPrice , price , discount , quantity , barcode , sku , productId , image , ...rest })=>({
                    ...rest
                }));
            const filterKey = Object.keys(Object.assign({}, ...res));
            const selectVar = filterKey?.reduce((obj, key)=>({
                    ...obj,
                    [key]: selectVariant[key]
                }), {});
            const newObj = Object.entries(selectVar).reduce((a, [k, v])=>v ? (a[k] = v, a) : a, {});
            const result2 = result?.find((v)=>Object.keys(newObj).every((k)=>newObj[k] === v[k]));
            // console.log("result2", result2);
            if (result.length <= 0 || result2 === undefined) return setStock(0);
            setVariants(result);
            setSelectVariant(result2);
            setSelectVa(result2);
            setImg(result2?.image);
            setPrice(Number(result2?.price));
            setOriginalPrice(Number(result2?.originalPrice));
            setStock(result2?.quantity);
            setDiscount(Number(result2?.discount));
        } else if (product?.variants?.length > 0) {
            const result1 = product?.variants?.filter((variant)=>Object.keys(selectVa).every((k)=>selectVa[k] === variant[k]));
            setVariants(result1);
            setPrice(Number(product.variants[0]?.price));
            setOriginalPrice(Number(product.variants[0]?.originalPrice));
            setStock(product.variants[0]?.quantity);
            setDiscount(Number(product.variants[0]?.discount));
            setSelectVariant(product.variants[0]);
            setSelectVa(product.variants[0]);
            setImg(product.variants[0]?.image);
        } else {
            setPrice(Number(product?.prices?.price));
            setOriginalPrice(Number(product?.prices?.originalPrice));
            setStock(product?.stock);
            setImg(product?.image[0]);
            setDiscount(Number(product?.prices?.discount));
        }
    }, [
        product?.prices?.discount,
        product?.prices?.originalPrice,
        product?.prices?.price,
        product?.stock,
        product.variants,
        selectVa,
        selectVariant,
        value, 
    ]);
    // console.log("product", product);
    (0,react__WEBPACK_IMPORTED_MODULE_14__.useEffect)(()=>{
        const res = Object.keys(Object.assign({}, ...product?.variants));
        const varTitle = attributes?.filter((att)=>res.includes(att?._id));
        setVariantTitle(varTitle?.sort());
    }, [
        variants,
        attributes
    ]);
    const handleAddToCart = (p)=>{
        if (p.variants.length === 1 && p.variants[0].quantity < 1) return (0,_utils_toast__WEBPACK_IMPORTED_MODULE_9__/* .notifyError */ .cB)("Insufficient stock");
        if (stock <= 0) return (0,_utils_toast__WEBPACK_IMPORTED_MODULE_9__/* .notifyError */ .cB)("Insufficient stock");
        if (product?.variants.map((variant)=>Object.entries(variant).sort().toString() === Object.entries(selectVariant).sort().toString())) {
            const newItem = {
                ...p,
                id: `${p?.variants.length <= 0 ? p._id : p._id + "-" + variantTitle?.map((att)=>selectVariant[att._id]).join("-")}`,
                title: `${p?.variants.length <= 0 ? (0,_utils_translate__WEBPACK_IMPORTED_MODULE_16__/* .showingTranslateValue */ .S6)(p.title, lang) : (0,_utils_translate__WEBPACK_IMPORTED_MODULE_16__/* .showingTranslateValue */ .S6)(p.title, lang) + "-" + variantTitle?.map((att)=>att.variants?.find((v)=>v._id === selectVariant[att._id])).map((el)=>(0,_utils_translate__WEBPACK_IMPORTED_MODULE_16__/* .showingTranslateValue */ .S6)(el?.name, lang))}`,
                image: img,
                variant: selectVariant || {},
                price: p.variants.length === 0 ? p.prices.originalPrice : price,
                originalPrice: p.variants.length === 0 ? p.prices.originalPrice : originalPrice
            };
            // console.log("newItem", newItem);
            handleAddItem(newItem);
        } else {
            return (0,_utils_toast__WEBPACK_IMPORTED_MODULE_9__/* .notifyError */ .cB)("Please select all variant first!");
        }
    };
    const handleMoreInfo = (slug)=>{
        setModalOpen(false);
        router.push(`/product/${slug}`);
        setIsLoading(!isLoading);
    };
    const category_name = (0,_utils_translate__WEBPACK_IMPORTED_MODULE_16__/* .showingTranslateValue */ .S6)(product?.category?.name)?.toLowerCase()?.replace(/[^A-Z0-9]+/gi, "-");
    // console.log("product", product, "stock", stock);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_modal_MainModal__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            modalOpen: modalOpen,
            setModalOpen: setModalOpen,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "inline-block overflow-y-auto h-full align-middle transition-all transform bg-white shadow-xl rounded-2xl",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex flex-col lg:flex-row md:flex-row w-full max-w-4xl overflow-hidden",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_12___default()), {
                            href: `/product/${product.slug}`,
                            passHref: true,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                onClick: ()=>setModalOpen(false),
                                className: "flex-shrink-0 flex items-center justify-center h-auto cursor-pointer",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_common_Discount__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                        product: product,
                                        discount: discount,
                                        modal: true
                                    }),
                                    product.image[0] ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_11___default()), {
                                        src: img || product.image[0],
                                        width: 420,
                                        height: 420,
                                        alt: "product"
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_11___default()), {
                                        src: "https://res.cloudinary.com/ahossain/image/upload/v1655097002/placeholder_kvepfp.png",
                                        width: 420,
                                        height: 420,
                                        alt: "product Image"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-full flex flex-col p-5 md:p-8 text-left",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "mb-2 md:mb-2.5 block -mt-1.5",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_12___default()), {
                                            href: `/product/${product.slug}`,
                                            passHref: true,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                onClick: ()=>setModalOpen(false),
                                                className: "text-heading text-lg md:text-xl lg:text-2xl font-semibold font-serif hover:text-black cursor-pointer",
                                                children: (0,_utils_translate__WEBPACK_IMPORTED_MODULE_16__/* .showingTranslateValue */ .S6)(product?.title, lang)
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: `${stock <= 0 ? "relative py-1 mb-2" : "relative"}`,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_common_Stock__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                stock: stock
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-sm leading-6 text-gray-500 md:leading-6",
                                    children: (0,_utils_translate__WEBPACK_IMPORTED_MODULE_16__/* .showingTranslateValue */ .S6)(product?.description, lang)
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex items-center my-4",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_common_Price__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        product: product,
                                        price: price,
                                        currency: currency,
                                        originalPrice: originalPrice
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "mb-1",
                                    children: variantTitle?.map((a, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h4", {
                                                    className: "text-sm py-1 font-serif text-gray-700 font-bold",
                                                    children: [
                                                        (0,_utils_translate__WEBPACK_IMPORTED_MODULE_16__/* .showingTranslateValue */ .S6)(a?.name, lang),
                                                        ":"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "flex flex-row mb-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_variants_VariantList__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                                        att: a._id,
                                                        lang: lang,
                                                        option: a.option,
                                                        setValue: setValue,
                                                        varTitle: variantTitle,
                                                        variants: product?.variants,
                                                        setSelectVa: setSelectVa,
                                                        selectVariant: selectVariant,
                                                        setSelectVariant: setSelectVariant
                                                    })
                                                })
                                            ]
                                        }, a._id))
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex items-center mt-4",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center justify-between space-s-3 sm:space-s-4 w-full",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "group flex items-center justify-between rounded-md overflow-hidden flex-shrink-0 border h-11 md:h-12 border-gray-300",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        onClick: ()=>setItem(item - 1),
                                                        disabled: item === 1,
                                                        className: "flex items-center justify-center flex-shrink-0 h-full transition ease-in-out duration-300 focus:outline-none w-8 md:w-12 text-heading border-e border-gray-300 hover:text-gray-500",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "text-dark text-base",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_15__.FiMinus, {})
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "font-semibold flex items-center justify-center h-full transition-colors duration-250 ease-in-out cursor-default flex-shrink-0 text-base text-heading w-8 md:w-20 xl:w-24",
                                                        children: item
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        onClick: ()=>setItem(item + 1),
                                                        disabled: product.quantity < item || product.quantity === item,
                                                        className: "flex items-center justify-center h-full flex-shrink-0 transition ease-in-out duration-300 focus:outline-none w-8 md:w-12 text-heading border-s border-gray-300 hover:text-gray-500",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "text-dark text-base",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_15__.FiPlus, {})
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                onClick: ()=>handleAddToCart(product),
                                                disabled: product.quantity < 1,
                                                className: "text-sm leading-4 inline-flex items-center cursor-pointer transition ease-in-out duration-300 font-semibold font-serif text-center justify-center border-0 border-transparent rounded-md focus-visible:outline-none focus:outline-none text-white px-4 ml-4 md:px-6 lg:px-8 py-4 md:py-3.5 lg:py-4 hover:text-white bg-emerald-500 hover:bg-emerald-600 w-full h-12",
                                                children: t("common:addToCart")
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex items-center mt-4",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center justify-between space-s-3 sm:space-s-4 w-full",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                        className: "font-serif font-semibold py-1 text-sm d-block",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                className: "text-gray-700",
                                                                children: [
                                                                    " ",
                                                                    t("common:category"),
                                                                    ":"
                                                                ]
                                                            }),
                                                            " ",
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_12___default()), {
                                                                href: `//menu?category=${category_name}&_id=${product?.category?._id}`,
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                    type: "button",
                                                                    className: "text-gray-600 font-serif font-medium underline ml-2 hover:text-teal-600",
                                                                    onClick: ()=>setIsLoading(!isLoading),
                                                                    children: category_name
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_common_Tags__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        product: product
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    onClick: ()=>handleMoreInfo(product.slug),
                                                    className: "font-sans font-medium text-sm text-orange-500",
                                                    children: t("common:moreInfo")
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductModal);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1743:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _component_common_Discount__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6517);
/* harmony import */ var _component_common_Price__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7493);
/* harmony import */ var _component_common_Stock__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6616);
/* harmony import */ var _component_modal_ProductModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3794);
/* harmony import */ var _hooks_useAddToCart__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1353);
/* harmony import */ var _hooks_useAsync__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9338);
/* harmony import */ var _services_SettingServices__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3644);
/* harmony import */ var _utils_toast__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8548);
/* harmony import */ var _utils_translate__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8837);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(866);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3521);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9878);
/* harmony import */ var react_use_cart__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_use_cart__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_component_modal_ProductModal__WEBPACK_IMPORTED_MODULE_4__, _services_SettingServices__WEBPACK_IMPORTED_MODULE_7__]);
([_component_modal_ProductModal__WEBPACK_IMPORTED_MODULE_4__, _services_SettingServices__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
















const ProductCard = ({ product , attributes  })=>{
    const { items , addItem , updateItemQuantity , inCart  } = (0,react_use_cart__WEBPACK_IMPORTED_MODULE_14__.useCart)();
    const { handleIncreaseQuantity  } = (0,_hooks_useAddToCart__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const { lang  } = next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_9___default()("ns1"); // default namespace (optional)
    const { 0: modalOpen , 1: setModalOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_12__.useState)(false);
    const { data: globalSetting  } = (0,_hooks_useAsync__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(_services_SettingServices__WEBPACK_IMPORTED_MODULE_7__/* ["default"].getGlobalSetting */ .Z.getGlobalSetting);
    const currency = globalSetting?.default_currency || "$";
    // console.log('attributes in product cart',attributes)
    const handleAddItem = (p)=>{
        if (p.stock < 1) return (0,_utils_toast__WEBPACK_IMPORTED_MODULE_8__/* .notifyError */ .cB)("Insufficient stock!");
        if (p?.variants?.length > 0) {
            setModalOpen(!modalOpen);
            return;
        }
        const newItem = {
            ...p,
            title: (0,_utils_translate__WEBPACK_IMPORTED_MODULE_15__/* .showingTranslateValue */ .S6)(p?.title, lang),
            id: p._id,
            variant: p.prices,
            price: p.prices.price,
            originalPrice: product.prices?.originalPrice
        };
        addItem(newItem);
    };
    const handleModalOpen = (event, id)=>{
        setModalOpen(event);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            modalOpen && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_modal_ProductModal__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                modalOpen: modalOpen,
                setModalOpen: setModalOpen,
                product: product,
                currency: currency,
                attributes: attributes
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "group box-border overflow-hidden flex rounded-md shadow-sm pe-0 flex-col items-center bg-white relative",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        onClick: ()=>handleModalOpen(!modalOpen, product._id),
                        className: "relative flex justify-center w-full cursor-pointer pt-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "left-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_common_Stock__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    product: product,
                                    stock: product.stock,
                                    card: true
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_common_Discount__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                product: product
                            }),
                            product?.image[0] ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_11___default()), {
                                src: product.image[0],
                                width: 210,
                                height: 210,
                                alt: "product",
                                className: "object-contain transition duration-150 ease-linear transform group-hover:scale-105"
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_11___default()), {
                                src: "https://res.cloudinary.com/ahossain/image/upload/v1655097002/placeholder_kvepfp.png",
                                width: 210,
                                height: 210,
                                alt: "product",
                                className: "object-cover transition duration-150 ease-linear transform group-hover:scale-105"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full px-3 lg:px-4 pb-4 overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "relative mb-1",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-gray-400 font-medium text-xs d-block mb-1",
                                        children: product.unit
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "text-heading truncate mb-0 block text-sm font-medium text-gray-600",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "line-clamp-2",
                                            children: (0,_utils_translate__WEBPACK_IMPORTED_MODULE_15__/* .showingTranslateValue */ .S6)(product?.title, lang)
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex justify-between items-center text-heading text-sm sm:text-base space-s-2 md:text-base lg:text-xl",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_common_Price__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        card: true,
                                        product: product,
                                        currency: currency,
                                        price: product.prices.price,
                                        originalPrice: product?.prices?.originalPrice
                                    }),
                                    inCart(product._id) ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            items.map((item)=>item.id === product._id && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "h-9 w-auto flex flex-wrap items-center justify-evenly py-1 px-2 bg-emerald-500 text-white rounded",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                            onClick: ()=>updateItemQuantity(item.id, item.quantity - 1),
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                className: "text-dark text-base",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_13__.IoRemove, {})
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "text-sm text-dark px-1 font-serif font-semibold",
                                                            children: item.quantity
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                            onClick: ()=>item?.variants?.length > 0 ? handleAddItem(item) : handleIncreaseQuantity(item),
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                className: "text-dark text-base",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_13__.IoAdd, {})
                                                            })
                                                        })
                                                    ]
                                                }, item.id)),
                                            " "
                                        ]
                                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                        onClick: ()=>handleAddItem(product),
                                        "aria-label": "cart",
                                        className: "h-9 w-9 flex items-center justify-center border border-gray-200 rounded text-emerald-500 hover:border-emerald-500 hover:bg-emerald-500 hover:text-white transition-all",
                                        children: [
                                            " ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-xl",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_13__.IoBagAddSharp, {})
                                            }),
                                            " "
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_dynamic__WEBPACK_IMPORTED_MODULE_10___default()(()=>Promise.resolve(ProductCard), {
    ssr: false
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2479:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_translate__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8837);


const VariantList = ({ att , option , variants , setValue , varTitle , selectVariant , setSelectVariant , setSelectVa , lang ,  })=>{
    const handleChangeVariant = (v)=>{
        setValue(v);
        setSelectVariant({
            ...selectVariant,
            [att]: v
        });
        setSelectVa({
            [att]: v
        });
    };
    // console.log("option", );
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: option === "Dropdown" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
            onChange: (e)=>handleChangeVariant(e.target.value),
            className: "focus:shadow-none w-1/2 px-2 py-1 form-select outline-none h-10 text-sm focus:outline-none block rounded-md bg-gray-100 border-transparent focus:bg-white border-emerald-600 focus:border-emerald-400 focus:ring focus:ring-emerald-200",
            name: "parent",
            children: [
                [
                    ...new Map(variants.map((v)=>[
                            v[att],
                            v
                        ].filter(Boolean))).values(), 
                ].filter(Boolean).map((vl, i)=>Object?.values(selectVariant).includes(vl[att]) && varTitle.map((vr)=>vr?.variants?.map((el)=>vr?._id === att && el?._id === vl[att] && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: selectVariant[att],
                                defaultValue: selectVariant[att],
                                hidden: true,
                                children: (0,_utils_translate__WEBPACK_IMPORTED_MODULE_1__/* .showingTranslateValue */ .S6)(el.name, lang)
                            }, i + 1)))),
                [
                    ...new Map(variants.map((v)=>[
                            v[att],
                            v
                        ].filter(Boolean))).values(), 
                ].filter(Boolean).map((vl, i)=>varTitle.map((vr)=>vr?.variants?.map((el)=>vr?._id === att && el?._id === vl[att] && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: vl[att],
                                defaultValue: true,
                                children: (0,_utils_translate__WEBPACK_IMPORTED_MODULE_1__/* .showingTranslateValue */ .S6)(el.name, lang)
                            }, el._id))))
            ]
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "grid lg:grid-cols-3 grid-cols-2",
            children: [
                ...new Map(variants?.map((v)=>[
                        v[att],
                        v
                    ].filter(Boolean))).values(), 
            ].filter(Boolean).map((vl, i)=>varTitle.map((vr)=>vr?.variants?.map((el)=>vr?._id === att && el?._id === vl[att] && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            onClick: (e)=>handleChangeVariant(vl[att]),
                            className: `${Object?.values(selectVariant).includes(vl[att]) ? "bg-emerald-500 text-white mr-2 border-0 rounded-full inline-flex items-center justify-center px-3 py-1 text-xs font-serif mt-2 focus:outline-none" : "bg-gray-100 mr-2 border-0 text-gray-600 rounded-full inline-flex items-center justify-center px-3 py-1 text-xs font-serif mt-2 focus:outline-none"}`,
                            children: (0,_utils_translate__WEBPACK_IMPORTED_MODULE_1__/* .showingTranslateValue */ .S6)(el.name, lang)
                        }, i + 1))))
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VariantList);


/***/ }),

/***/ 7576:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _httpServices__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8272);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_httpServices__WEBPACK_IMPORTED_MODULE_0__]);
_httpServices__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const AttributeServices = {
    getAllAttributes: async ()=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/attributes");
    },
    getShowingAttributes: async ()=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/attributes/show`);
    },
    addAttribute: async (body)=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/attributes/add", body);
    },
    addAllAttributes: async (body)=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/attributes/add/all", body);
    },
    getAttributeById: async (id)=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/attributes/${id}`);
    },
    updateAttributes: async (id, body)=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].put */ .Z.put(`/attributes/${id}`, body);
    },
    updateStatus: async (id, body)=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].put */ .Z.put(`/attributes/status/${id}`, body);
    },
    deleteAttribute: async (id, body)=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"]["delete"] */ .Z["delete"](`/attributes/${id}`, body);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AttributeServices);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2981:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _httpServices__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8272);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_httpServices__WEBPACK_IMPORTED_MODULE_0__]);
_httpServices__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const ProductServices = {
    getShowingProducts: async ()=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/products/show");
    },
    getShowingStoreProducts: async ({ category ="" , title =""  })=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/products/store?category=${category}&title=${title}`);
    },
    getDiscountedProducts: async ()=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/products/discount");
    },
    getProductBySlug: async (slug)=>{
        return _httpServices__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/products/${slug}`);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductServices);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;