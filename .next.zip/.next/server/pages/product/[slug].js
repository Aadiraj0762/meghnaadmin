"use strict";
(() => {
var exports = {};
exports.id = 915;
exports.ids = [915];
exports.modules = {

/***/ 9472:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3521);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3877);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3015);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper__WEBPACK_IMPORTED_MODULE_4__, swiper_react__WEBPACK_IMPORTED_MODULE_5__]);
([swiper__WEBPACK_IMPORTED_MODULE_4__, swiper_react__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



 // requires a loader






const ImageCarousel = ({ images , handleChangeImage , prevRef , nextRef  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(swiper_react__WEBPACK_IMPORTED_MODULE_5__.Swiper, {
            onInit: (swiper)=>{
                swiper.params.navigation.prevEl = prevRef.current;
                swiper.params.navigation.nextEl = nextRef.current;
                swiper.navigation.init();
                swiper.navigation.update();
            },
            spaceBetween: 1,
            navigation: true,
            allowTouchMove: false,
            loop: true,
            slidesPerView: 4,
            // breakpoints={{
            //   // when window width is >= 640px
            //   375: {
            //     width: 375,
            //     slidesPerView: 2,
            //   },
            //   // when window width is >= 768px
            //   414: {
            //     width: 414,
            //     slidesPerView: 3,
            //   },
            //   // when window width is >= 768px
            //   660: {
            //     width: 660,
            //     slidesPerView: 4,
            //   },
            //   // when window width is >= 768px
            //   768: {
            //     width: 768,
            //     slidesPerView: 6,
            //   },
            //   // when window width is >= 768px
            //   991: {
            //     width: 991,
            //     slidesPerView: 8,
            //   },
            //   // when window width is >= 768px
            //   1140: {
            //     width: 1140,
            //     slidesPerView: 9,
            //   },
            //   1680: {
            //     width: 1680,
            //     slidesPerView: 10,
            //   },
            //   1920: {
            //     width: 1920,
            //     slidesPerView: 10,
            //   },
            // }}
            modules: [
                swiper__WEBPACK_IMPORTED_MODULE_4__.Navigation
            ],
            className: "mySwiper image-carousel",
            children: [
                images?.map((img, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_5__.SwiperSlide, {
                        className: "group",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            onClick: ()=>handleChangeImage(img),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                className: "border inline-flex items-center justify-center px-3 py-1 mt-2",
                                src: img,
                                alt: "product",
                                width: 100,
                                height: 100
                            })
                        })
                    }, i + 1)),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    ref: prevRef,
                    className: "prev",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_3__.IoChevronBackOutline, {})
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    ref: nextRef,
                    className: "next",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_3__.IoChevronForward, {})
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_dynamic__WEBPACK_IMPORTED_MODULE_1___default()(()=>Promise.resolve(ImageCarousel), {
    ssr: false
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7208:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_2__);



const Card = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
        className: "my-0",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                className: "flex items-center py-3",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-xl text-gray-400 items-start mr-4",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_2__.FiTruck, {})
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                        className: "font-sans leading-5 text-sm text-gray-500",
                        children: [
                            "Free shipping apply to all orders over shipping",
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "font-semibold",
                                children: "$100"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                className: "flex items-center py-3",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-xl text-gray-400 items-start mr-4",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_2__.FiHome, {})
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                        className: "font-sans leading-5 text-sm text-gray-500",
                        children: [
                            "Home Delivery within ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "font-semibold",
                                children: "1 Hour"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                className: "flex items-center py-3",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-xl text-gray-400 items-start mr-4",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_2__.FiDollarSign, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "font-sans leading-5 text-sm text-gray-500",
                        children: "Cash on Delivery Available"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                className: "flex items-center py-3",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-xl text-gray-400 items-start mr-4",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_2__.FiRepeat, {})
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                        className: "font-sans leading-5 text-sm text-gray-500",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "font-semibold",
                                children: "7"
                            }),
                            " Days returns money back guarantee"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                className: "flex items-center py-3",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-xl text-gray-400 items-start mr-4",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_2__.FiShieldOff, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "font-sans leading-5 text-sm text-gray-500",
                        children: "Warranty not available this item"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                className: "flex items-center py-3",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-xl text-gray-400 items-start mr-4",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_2__.FiSun, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "font-sans leading-5 text-sm text-gray-500",
                        children: "Guaranteed 100% organic from natural products."
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                className: "flex items-center py-3",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-xl text-gray-400 items-start mr-4",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_2__.FiMapPin, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "font-sans leading-5 text-sm text-gray-500",
                        children: "Delivery from our pick point Cecilia Chapman, 561-4535 Nulla LA, United States 96522"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Card);


/***/ }),

/***/ 7890:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _next_translate_root_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(608);
/* harmony import */ var next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7462);
/* harmony import */ var next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(866);
/* harmony import */ var next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8027);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(543);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6158);
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_share__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _component_carousel_ImageCarousel__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9472);
/* harmony import */ var _component_common_Discount__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6517);
/* harmony import */ var _component_common_Price__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7493);
/* harmony import */ var _component_common_Stock__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6616);
/* harmony import */ var _component_common_Tags__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(386);
/* harmony import */ var _component_preloader_Loading__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8906);
/* harmony import */ var _component_product_ProductCard__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1743);
/* harmony import */ var _component_slug_card_Card__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(7208);
/* harmony import */ var _component_variants_VariantList__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(2479);
/* harmony import */ var _context_SidebarContext__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(6812);
/* harmony import */ var _hooks_useAddToCart__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(1353);
/* harmony import */ var _layout_Layout__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(1286);
/* harmony import */ var _services_AttributeServices__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(7576);
/* harmony import */ var _services_ProductServices__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(2981);
/* harmony import */ var _utils_toast__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(8548);
/* harmony import */ var _utils_translate__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(8837);
/* harmony import */ var _hooks_useAsync__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(9338);
/* harmony import */ var _services_SettingServices__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(3644);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_component_carousel_ImageCarousel__WEBPACK_IMPORTED_MODULE_10__, _component_product_ProductCard__WEBPACK_IMPORTED_MODULE_16__, _layout_Layout__WEBPACK_IMPORTED_MODULE_21__, _services_AttributeServices__WEBPACK_IMPORTED_MODULE_22__, _services_ProductServices__WEBPACK_IMPORTED_MODULE_23__, _services_SettingServices__WEBPACK_IMPORTED_MODULE_26__]);
([_component_carousel_ImageCarousel__WEBPACK_IMPORTED_MODULE_10__, _component_product_ProductCard__WEBPACK_IMPORTED_MODULE_16__, _layout_Layout__WEBPACK_IMPORTED_MODULE_21__, _services_AttributeServices__WEBPACK_IMPORTED_MODULE_22__, _services_ProductServices__WEBPACK_IMPORTED_MODULE_23__, _services_SettingServices__WEBPACK_IMPORTED_MODULE_26__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










//internal import


















const ProductScreen = ({ product , attributes , relatedProduct  })=>{
    // console.log('attributes',attributes)
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const prevRef = (0,react__WEBPACK_IMPORTED_MODULE_7__.useRef)(null);
    const nextRef = (0,react__WEBPACK_IMPORTED_MODULE_7__.useRef)(null);
    const { data: globalSetting  } = (0,_hooks_useAsync__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .Z)(_services_SettingServices__WEBPACK_IMPORTED_MODULE_26__/* ["default"].getGlobalSetting */ .Z.getGlobalSetting);
    const currency = globalSetting?.default_currency || "$";
    // console.log('product',product)
    const { isLoading , setIsLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_context_SidebarContext__WEBPACK_IMPORTED_MODULE_19__/* .SidebarContext */ .l);
    const { handleAddItem , item , setItem  } = (0,_hooks_useAddToCart__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z)();
    const { lang  } = next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_3___default()("ns1"); // default namespace (optional)
    // react hook
    const { 0: value , 1: setValue  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)("");
    const { 0: price , 1: setPrice  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(0);
    const { 0: img , 1: setImg  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)("");
    const { 0: originalPrice , 1: setOriginalPrice  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(0);
    const { 0: stock , 1: setStock  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)("");
    const { 0: discount , 1: setDiscount  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)("");
    const { 0: selectVariant , 1: setSelectVariant  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const { 0: isReadMore , 1: setIsReadMore  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(true);
    const { 0: selectVa , 1: setSelectVa  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const { 0: variantTitle , 1: setVariantTitle  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)([]);
    const { 0: variants , 1: setVariants  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        if (value) {
            const result = product?.variants?.filter((variant)=>Object.keys(selectVa).every((k)=>selectVa[k] === variant[k]));
            // console.log('result',result)
            const res = result?.map(({ originalPrice , discount , quantity , inUse , inUseOrder , barcode , sku , productId , image , ...rest })=>({
                    ...rest
                }));
            // console.log("res", res);
            const filterKey = Object.keys(Object.assign({}, ...res));
            const selectVar = filterKey?.reduce((obj, key)=>({
                    ...obj,
                    [key]: selectVariant[key]
                }), {});
            const newObj = Object.entries(selectVar).reduce((a, [k, v])=>v ? (a[k] = v, a) : a, {});
            const result2 = result?.find((v)=>Object.keys(newObj).every((k)=>newObj[k] === v[k]));
            // console.log("result2", result2);
            if (result.length <= 0 || result2 === undefined) return setStock(0);
            setVariants(result);
            setSelectVariant(result2);
            setSelectVa(result2);
            setImg(result2?.image);
            setPrice(Number(result2?.price));
            setOriginalPrice(Number(result2?.originalPrice));
            setStock(result2?.quantity);
            setDiscount(Number(result2?.discount));
        } else if (product?.variants?.length > 0) {
            const result1 = product?.variants?.filter((variant)=>Object.keys(selectVa).every((k)=>selectVa[k] === variant[k]));
            setVariants(result1);
            setPrice(Number(product.variants[0]?.price));
            setOriginalPrice(Number(product.variants[0]?.originalPrice));
            setStock(product.variants[0]?.quantity);
            setDiscount(Number(product.variants[0]?.discount));
            setSelectVariant(product.variants[0]);
            setSelectVa(product.variants[0]);
            setImg(product.variants[0]?.image);
        } else {
            setPrice(Number(product?.prices?.price));
            setOriginalPrice(Number(product?.prices?.originalPrice));
            setStock(product?.stock);
            setDiscount(Number(product?.prices?.discount));
            setImg(product?.image[0]);
        }
    }, [
        product?.prices?.discount,
        product?.prices?.originalPrice,
        product?.prices?.price,
        product?.stock,
        product.variants,
        selectVa,
        selectVariant,
        value, 
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        const res = Object.keys(Object.assign({}, ...product?.variants));
        const varTitle = attributes?.filter((att)=>res.includes(att?._id));
        setVariantTitle(varTitle?.sort());
    }, [
        variants,
        attributes
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        setIsLoading(false);
    }, [
        product
    ]);
    const handleAddToCart = (p)=>{
        if (p.variants.length === 1 && p.variants[0].quantity < 1) return (0,_utils_toast__WEBPACK_IMPORTED_MODULE_24__/* .notifyError */ .cB)("Insufficient stock");
        // if (notAvailable) return notifyError('This Variation Not Available Now!');
        if (stock <= 0) return (0,_utils_toast__WEBPACK_IMPORTED_MODULE_24__/* .notifyError */ .cB)("Insufficient stock");
        // console.log('selectVariant', selectVariant);
        if (product?.variants.map((variant)=>Object.entries(variant).sort().toString() === Object.entries(selectVariant).sort().toString())) {
            const newItem = {
                ...p,
                id: `${p.variants.length <= 1 ? p._id : p._id + variantTitle?.map(// (att) => selectVariant[att.title.replace(/[^a-zA-Z0-9]/g, '')]
                (att)=>selectVariant[att._id]).join("-")}`,
                title: `${p.variants.length <= 1 ? (0,_utils_translate__WEBPACK_IMPORTED_MODULE_27__/* .showingTranslateValue */ .S6)(product?.title, lang) : (0,_utils_translate__WEBPACK_IMPORTED_MODULE_27__/* .showingTranslateValue */ .S6)(product?.title, lang) + "-" + variantTitle?.map(// (att) => selectVariant[att.title.replace(/[^a-zA-Z0-9]/g, '')]
                (att)=>att.variants?.find((v)=>v._id === selectVariant[att._id])).map((el)=>Object.keys(el?.name).includes(lang) ? el?.name[lang] : el?.name.en)}`,
                variant: selectVariant,
                price: price,
                originalPrice: originalPrice
            };
            handleAddItem(newItem);
        } else {
            return (0,_utils_toast__WEBPACK_IMPORTED_MODULE_24__/* .notifyError */ .cB)("Please select all variant first!");
        }
    };
    const handleChangeImage = (img)=>{
        setImg(img);
    };
    const { t  } = next_translate_useTranslation__WEBPACK_IMPORTED_MODULE_3___default()();
    // category name slug
    const category_name = (0,_utils_translate__WEBPACK_IMPORTED_MODULE_27__/* .showingTranslateValue */ .S6)(product?.category?.name).toLowerCase().replace(/[^A-Z0-9]+/gi, "-");
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_preloader_Loading__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
            loading: isLoading
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layout_Layout__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
            title: (0,_utils_translate__WEBPACK_IMPORTED_MODULE_27__/* .showingTranslateValue */ .S6)(product?.title, lang),
            description: (0,_utils_translate__WEBPACK_IMPORTED_MODULE_27__/* .showingTranslateValue */ .S6)(product.description, lang),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "px-0 py-10 lg:py-10",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mx-auto px-3 lg:px-10 max-w-screen-2xl",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex items-center pb-4",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ol", {
                                className: "flex items-center w-full overflow-hidden font-serif",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "text-sm pr-1 transition duration-200 ease-in cursor-pointer hover:text-emerald-500 font-semibold",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            href: "/",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                children: "Home"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "text-sm mt-[1px]",
                                        children: [
                                            " ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_8__.FiChevronRight, {}),
                                            " "
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "text-sm pl-1 transition duration-200 ease-in cursor-pointer hover:text-emerald-500 font-semibold ",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            href: `//menu?category=${category_name}&_id=${product?.category?._id}`,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                type: "button",
                                                onClick: ()=>setIsLoading(!isLoading),
                                                children: category_name
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "text-sm mt-[1px]",
                                        children: [
                                            " ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_8__.FiChevronRight, {}),
                                            " "
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "text-sm px-1 transition duration-200 ease-in ",
                                        children: (0,_utils_translate__WEBPACK_IMPORTED_MODULE_27__/* .showingTranslateValue */ .S6)(product?.title, lang)
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full rounded-lg p-3 lg:p-12 bg-white",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col xl:flex-row",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex-shrink-0 xl:pr-10 lg:block w-full mx-auto md:w-6/12 lg:w-5/12 xl:w-4/12",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_common_Discount__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                slug: true,
                                                product: product,
                                                discount: discount
                                            }),
                                            product.image[0] ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                src: img || product.image[0],
                                                alt: "product",
                                                width: 650,
                                                height: 650,
                                                priority: true
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                src: "https://res.cloudinary.com/ahossain/image/upload/v1655097002/placeholder_kvepfp.png",
                                                width: 650,
                                                height: 650,
                                                alt: "product Image"
                                            }),
                                            product.image.length > 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "flex flex-row flex-wrap mt-4 border-t",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_carousel_ImageCarousel__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                                    images: product.image,
                                                    handleChangeImage: handleChangeImage,
                                                    prevRef: prevRef,
                                                    nextRef: nextRef
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "w-full",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex flex-col md:flex-row lg:flex-row xl:flex-row",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: " w-3/5 xl:pr-6 md:pr-6 md:w-2/3 mob-w-full",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "mb-6",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                                    className: "leading-7 text-lg md:text-xl lg:text-2xl mb-1 font-semibold font-serif text-gray-800",
                                                                    children: (0,_utils_translate__WEBPACK_IMPORTED_MODULE_27__/* .showingTranslateValue */ .S6)(product?.title, lang)
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                    className: "uppercase font-serif font-medium text-gray-500 text-sm",
                                                                    children: [
                                                                        "SKU :",
                                                                        " ",
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                            className: "font-bold text-gray-600",
                                                                            children: product.sku
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "relative",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_common_Stock__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                                        stock: stock
                                                                    })
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_common_Price__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                            price: price,
                                                            product: product,
                                                            currency: currency,
                                                            originalPrice: originalPrice
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "mb-4",
                                                            children: variantTitle?.map((a, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h4", {
                                                                            className: "text-sm py-1",
                                                                            children: [
                                                                                (0,_utils_translate__WEBPACK_IMPORTED_MODULE_27__/* .showingTranslateValue */ .S6)(a?.name, lang),
                                                                                ":"
                                                                            ]
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "flex flex-row mb-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_variants_VariantList__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                                                                                att: a._id,
                                                                                lang: lang,
                                                                                option: a.option,
                                                                                setValue: setValue,
                                                                                varTitle: variantTitle,
                                                                                setSelectVa: setSelectVa,
                                                                                variants: product.variants,
                                                                                selectVariant: selectVariant,
                                                                                setSelectVariant: setSelectVariant
                                                                            })
                                                                        })
                                                                    ]
                                                                }, i + 1))
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "text-sm leading-6 text-gray-500 md:leading-7",
                                                                    children: [
                                                                        isReadMore ? (0,_utils_translate__WEBPACK_IMPORTED_MODULE_27__/* .showingTranslateValue */ .S6)(product?.description, lang)?.slice(0, 230) : (0,_utils_translate__WEBPACK_IMPORTED_MODULE_27__/* .showingTranslateValue */ .S6)(product?.description, lang),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                                        Object?.keys(product?.description)?.includes(lang) ? product?.description[lang]?.length > 230 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                            onClick: ()=>setIsReadMore(!isReadMore),
                                                                            className: "read-or-hide",
                                                                            children: isReadMore ? t("common:moreInfo") : t("common:showLess")
                                                                        }) : product?.description?.en?.length > 230 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                            onClick: ()=>setIsReadMore(!isReadMore),
                                                                            className: "read-or-hide",
                                                                            children: isReadMore ? t("common:moreInfo") : t("common:showLess")
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "flex items-center mt-4",
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: "flex items-center justify-between space-s-3 sm:space-s-4 w-full",
                                                                        children: [
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                className: "group flex items-center justify-between rounded-md overflow-hidden flex-shrink-0 border h-11 md:h-12 border-gray-300",
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                        onClick: ()=>setItem(item - 1),
                                                                                        disabled: item === 1,
                                                                                        className: "flex items-center justify-center flex-shrink-0 h-full transition ease-in-out duration-300 focus:outline-none w-8 md:w-12 text-heading border-e border-gray-300 hover:text-gray-500",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                            className: "text-dark text-base",
                                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_8__.FiMinus, {})
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                        className: "font-semibold flex items-center justify-center h-full transition-colors duration-250 ease-in-out cursor-default flex-shrink-0 text-base text-heading w-8 md:w-20 xl:w-24",
                                                                                        children: item
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                        onClick: ()=>setItem(item + 1),
                                                                                        disabled: selectVariant?.quantity <= item,
                                                                                        className: "flex items-center justify-center h-full flex-shrink-0 transition ease-in-out duration-300 focus:outline-none w-8 md:w-12 text-heading border-s border-gray-300 hover:text-gray-500",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                            className: "text-dark text-base",
                                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_8__.FiPlus, {})
                                                                                        })
                                                                                    })
                                                                                ]
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                onClick: ()=>handleAddToCart(product),
                                                                                className: "text-sm leading-4 inline-flex items-center cursor-pointer transition ease-in-out duration-300 font-semibold font-serif text-center justify-center border-0 border-transparent rounded-md focus-visible:outline-none focus:outline-none text-white px-4 ml-4 md:px-6 lg:px-8 py-4 md:py-3.5 lg:py-4 hover:text-white bg-emerald-500 hover:bg-emerald-600 w-full h-12",
                                                                                children: t("common:addToCart")
                                                                            })
                                                                        ]
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "flex flex-col mt-4",
                                                                    children: [
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                            className: "font-serif font-semibold py-1 text-sm d-block",
                                                                            children: [
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                    className: "text-gray-800",
                                                                                    children: [
                                                                                        t("common:category"),
                                                                                        ":"
                                                                                    ]
                                                                                }),
                                                                                " ",
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                                                    href: `//menu?category=${category_name}&_id=${product?.category?._id}`,
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                        type: "button",
                                                                                        className: "text-gray-600 font-serif font-medium underline ml-2 hover:text-teal-600",
                                                                                        onClick: ()=>setIsLoading(!isLoading),
                                                                                        children: category_name
                                                                                    })
                                                                                })
                                                                            ]
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_common_Tags__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                                                            product: product
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "mt-8",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                                            className: "text-base font-semibold mb-1 font-serif",
                                                                            children: t("common:shareYourSocial")
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                            className: "font-sans text-sm text-gray-500",
                                                                            children: t("common:shareYourSocialText")
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                                            className: "flex mt-4",
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                    className: "flex items-center text-center border border-gray-100 rounded-full hover:bg-emerald-500 mr-2 transition ease-in-out duration-500",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_9__.FacebookShareButton, {
                                                                                        url: `https://supermarket-plum.vercel.app/product/${router.query.slug}`,
                                                                                        quote: "",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_9__.FacebookIcon, {
                                                                                            size: 32,
                                                                                            round: true
                                                                                        })
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                    className: "flex items-center text-center border border-gray-100 rounded-full hover:bg-emerald-500 mr-2 transition ease-in-out duration-500",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_9__.TwitterShareButton, {
                                                                                        url: `https://supermarket-plum.vercel.app/product/${router.query.slug}`,
                                                                                        quote: "",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_9__.TwitterIcon, {
                                                                                            size: 32,
                                                                                            round: true
                                                                                        })
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                    className: "flex items-center text-center border border-gray-100 rounded-full hover:bg-emerald-500 mr-2 transition ease-in-out duration-500",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_9__.RedditShareButton, {
                                                                                        url: `https://supermarket-plum.vercel.app/product/${router.query.slug}`,
                                                                                        quote: "",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_9__.RedditIcon, {
                                                                                            size: 32,
                                                                                            round: true
                                                                                        })
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                    className: "flex items-center text-center border border-gray-100 rounded-full hover:bg-emerald-500 mr-2 transition ease-in-out duration-500",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_9__.WhatsappShareButton, {
                                                                                        url: `https://supermarket-plum.vercel.app/product/${router.query.slug}`,
                                                                                        quote: "",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_9__.WhatsappIcon, {
                                                                                            size: 32,
                                                                                            round: true
                                                                                        })
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                                    className: "flex items-center text-center border border-gray-100 rounded-full hover:bg-emerald-500 mr-2 transition ease-in-out duration-500",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_9__.LinkedinShareButton, {
                                                                                        url: `https://supermarket-plum.vercel.app/product/${router.query.slug}`,
                                                                                        quote: "",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_9__.LinkedinIcon, {
                                                                                            size: 32,
                                                                                            round: true
                                                                                        })
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "w-full xl:w-5/12 lg:w-6/12 md:w-5/12",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "mt-6 md:mt-0 lg:mt-0 bg-gray-50 border border-gray-100 p-4 lg:p-8 rounded-lg",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_slug_card_Card__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {})
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        }),
                        relatedProduct?.length >= 2 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "pt-10 lg:pt-20 lg:pb-10",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "leading-7 text-lg lg:text-xl mb-3 font-semibold font-serif hover:text-gray-600",
                                    children: t("common:relatedProducts")
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "w-full",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 xl:grid-cols-5 2xl:grid-cols-6 gap-2 md:gap-3 lg:gap-3",
                                            children: relatedProduct?.slice(1, 13).map((product, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_product_ProductCard__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                                    product: product,
                                                    attributes: attributes
                                                }, product._id))
                                        })
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
};
// you can use getServerSideProps alternative for getStaticProps and getStaticPaths
const _getServerSideProps = async (context)=>{
    const { slug  } = context.params;
    const [data, attributes] = await Promise.all([
        _services_ProductServices__WEBPACK_IMPORTED_MODULE_23__/* ["default"].getShowingStoreProducts */ .Z.getShowingStoreProducts({
            category: "",
            title: slug
        }),
        _services_AttributeServices__WEBPACK_IMPORTED_MODULE_22__/* ["default"].getShowingAttributes */ .Z.getShowingAttributes({}), 
    ]);
    let product = {};
    if (slug) {
        product = data?.products?.find((p)=>p.slug === slug);
    }
    return {
        props: {
            product,
            relatedProduct: data?.relatedProduct,
            attributes
        }
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductScreen);
async function getServerSideProps(ctx) {
    let res = _getServerSideProps(ctx);
    if (typeof res.then === "function") res = await res;
    return {
        ...res,
        props: {
            ...res.props || {},
            ...await next_translate_loadNamespaces__WEBPACK_IMPORTED_MODULE_2___default()({
                ...ctx,
                pathname: "/product/[slug]",
                loaderName: "getServerSideProps",
                ..._next_translate_root_i18n__WEBPACK_IMPORTED_MODULE_1__,
                loadLocaleFrom: (l, n)=>__webpack_require__(7655)(`./${l}/${n}`).then((m)=>m.default)
            })
        }
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8768:
/***/ ((module) => {

module.exports = require("@heroicons/react/outline");

/***/ }),

/***/ 6999:
/***/ ((module) => {

module.exports = require("@react-oauth/google");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 7462:
/***/ ((module) => {

module.exports = require("next-translate/loadNamespaces");

/***/ }),

/***/ 866:
/***/ ((module) => {

module.exports = require("next-translate/useTranslation");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 5307:
/***/ ((module) => {

module.exports = require("rc-drawer");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 2750:
/***/ ((module) => {

module.exports = require("react-icons/fi");

/***/ }),

/***/ 1111:
/***/ ((module) => {

module.exports = require("react-icons/hi");

/***/ }),

/***/ 924:
/***/ ((module) => {

module.exports = require("react-icons/im");

/***/ }),

/***/ 9989:
/***/ ((module) => {

module.exports = require("react-icons/io5");

/***/ }),

/***/ 6158:
/***/ ((module) => {

module.exports = require("react-share");

/***/ }),

/***/ 2633:
/***/ ((module) => {

module.exports = require("react-spinners/ScaleLoader");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 9878:
/***/ ((module) => {

module.exports = require("react-use-cart");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ }),

/***/ 9915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 3877:
/***/ ((module) => {

module.exports = import("swiper");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [678,138,103,670,557,812,8,286,12], () => (__webpack_exec__(7890)));
module.exports = __webpack_exports__;

})();